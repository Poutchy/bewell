package com.taass.payement_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
