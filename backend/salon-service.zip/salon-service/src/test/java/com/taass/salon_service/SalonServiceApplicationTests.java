package com.taass.salon_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalonServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
